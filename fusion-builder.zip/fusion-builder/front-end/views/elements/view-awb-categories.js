var FusionPageBuilder = FusionPageBuilder || {};

( function() {

	jQuery( document ).ready( function() {

		FusionPageBuilder.awb_categories = FusionPageBuilder.ElementView.extend( {

			/**
			 * Modify template attributes.
			 *
			 * @since 3.16
			 * @param {Object} atts - The attributes.
			 * @return {Object}
			 */
			filterTemplateAtts: function( atts ) {
				var attributes = {};

				this.values = atts.values;

				attributes.attr   = this.buildAttr( atts.values );
				attributes.output = this.buildOutput( atts );

				return attributes;
			},

			/**
			 * Builds the wrapper attributes.
			 *
			 * @since 3.16
			 * @param {Object} values - The values object.
			 * @return {Object}
			 */
			buildAttr: function( values ) {
				var attr         = {
						class: 'awb-categories awb-categories-cid-' + this.model.get( 'cid' ),
						style: ''
					},
					hierarchical = this.getHierarchical( values );

				attr[ 'class' ] += ' awb-categories--' + values.display_type;

				if ( 'list' === values.display_type ) {
					attr[ 'class' ] += ' awb-categories--' + values.layout;

					if ( 'yes' === hierarchical ) {
						attr[ 'class' ] += ' awb-categories--hierarchical awb-categories--subs-' + values.sub_display;
						attr[ 'class' ] += ' awb-categories--indent-' + values.sub_indent_style;

						if ( 'yes' === values.sub_grouped ) {
							attr[ 'class' ] += ' awb-categories--subs-grouped';
						}

						if ( 'content' === values.toggle_position && 'accordion' === values.sub_display && 'space-between' !== values.item_align ) {
							attr[ 'class' ] += ' awb-categories--toggle-content';
						}
					}

					if ( 'never' !== values.collapse_to_select ) {
						attr[ 'class' ] += ' awb-categories--collapse-' + values.collapse_to_select;
					}
				}

				if ( '' !== values.icon ) {
					attr[ 'class' ] += ' awb-categories--has-icon';
				}

				if ( 'yes' === values.show_image ) {
					attr[ 'class' ] += ' awb-categories--has-image';
				}

				if ( '' !== values[ 'class' ] ) {
					attr[ 'class' ] += ' ' + values[ 'class' ];
				}

				if ( '' !== values.id ) {
					attr.id = values.id;
				}

				attr = _.fusionVisibilityAtts( values.hide_on_mobile, attr );
				attr = _.fusionAnimations( values, attr );

				attr.style += this.getStyleVariables( values );

				return attr;
			},

			/**
			 * The inline layout is always flat, mirroring the PHP side.
			 *
			 * @since 3.16
			 * @param {Object} values - The values object.
			 * @return {String}
			 */
			getHierarchical: function( values ) {
				if ( 'inline' === values.layout && 'list' === values.display_type ) {
					return 'no';
				}

				return values.hierarchical;
			},

			/**
			 * Builds the output, which is rendered server side.
			 *
			 * @since 3.16
			 * @param {Object} atts - The atts object.
			 * @return {String}
			 */
			buildOutput: function( atts ) {
				if ( 'undefined' !== typeof atts.query_data && 'undefined' !== typeof atts.query_data.output ) {
					return atts.query_data.output;
				}

				if ( 'undefined' !== typeof atts.markup && 'undefined' !== typeof atts.markup.output ) {
					return atts.markup.output;
				}

				return '';
			},

			/**
			 * Gets the style variables.
			 *
			 * @since 3.16
			 * @param {Object} values - The values object.
			 * @return {String}
			 */
			getStyleVariables: function( values ) {
				var customVars     = {},
					cssVarsOptions = [
						'item_align',
						'inline_justify',
						'separator_style',
						'separator_color',
						'item_color',
						'item_hover_color',
						'item_bgcolor',
						'item_hover_bgcolor',
						'item_border_style',
						'item_border_color',
						'item_hover_border_color',
						'count_color',
						'count_hover_color',
						'icon_color',
						'icon_hover_color',
						'toggle_color',
						'toggle_hover_color',
						'select_color',
						'select_bgcolor',
						'select_border_color',
						'select_focus_border_color',
						'item_line_height',
						'item_text_transform',
						'count_line_height',
						'count_text_transform'
					],
					unitOptions    = [
						'max_width',
						'max_width_medium',
						'max_width_small',
						'margin_top',
						'margin_right',
						'margin_bottom',
						'margin_left',
						'margin_top_medium',
						'margin_right_medium',
						'margin_bottom_medium',
						'margin_left_medium',
						'margin_top_small',
						'margin_right_small',
						'margin_bottom_small',
						'margin_left_small',
						'item_padding_top',
						'item_padding_right',
						'item_padding_bottom',
						'item_padding_left',
						'item_border_top',
						'item_border_right',
						'item_border_bottom',
						'item_border_left',
						'border_radius_top_left',
						'border_radius_top_right',
						'border_radius_bottom_right',
						'border_radius_bottom_left',
						'item_gap',
						'sub_indent',
						'separator_size',
						'icon_size',
						'image_width',
						'image_border_radius',
						'media_gap',
						'select_border_radius',
						'select_height',
						'item_font_size',
						'item_letter_spacing',
						'count_font_size',
						'count_letter_spacing'
					];

				_.each( unitOptions, function( option ) {
					cssVarsOptions[ option ] = { callback: _.fusionGetValueWithUnit };
				} );

				customVars = this.getFontVars( 'item_font', values, customVars );
				customVars = this.getFontVars( 'count_font', values, customVars );

				return this.getCssVarsForOptions( cssVarsOptions ) + this.getCustomCssVars( customVars );
			},

			/**
			 * Adds the typography vars of a font param, matching get_font_styling_vars() on the PHP side.
			 *
			 * @since 3.16
			 * @param {String} key        - The typography param key.
			 * @param {Object} values     - The values object.
			 * @param {Object} customVars - The custom vars object.
			 * @return {Object}
			 */
			getFontVars: function( key, values, customVars ) {
				var fontStyles = _.fusionGetFontStyle( key, values, 'array' ),
					prefix     = key.replace( '_font', '' );

				_.each( fontStyles, function( value, rule ) {
					customVars[ prefix + '_' + rule.replace( /-/g, '_' ) ] = value;
				} );

				return customVars;
			},

			/**
			 * Runs after the view DOM is patched.
			 *
			 * @since 3.16
			 * @return {void}
			 */
			afterPatch: function() {
				this._refreshJs();
			}
		} );
	} );
}( jQuery ) );
