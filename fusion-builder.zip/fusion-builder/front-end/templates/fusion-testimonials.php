<?php
/**
 * Underscore.js template
 *
 * @package fusion-builder
 * @since 2.0
 */

?>
<script type="text/html" id="tmpl-fusion_testimonials-shortcode">
<div {{{ _.fusionGetAttributes( attr ) }}}>
	<# if ( ! useSwiper ) { #>
		<div {{{ _.fusionGetAttributes( carouselAttr ) }}}></div>
	<# } else { #>
		<div {{{ _.fusionGetAttributes( carouselAttr ) }}}>
			<div class="swiper-wrapper fusion-child-element"></div>

			<# if ( ( 'yes' === navigation || 'arrows_dots' === navigation ) && 1 < children ) { #>
				<div {{{ _.fusionGetAttributes( paginationAttr ) }}}></div>
			<# } #>
			<# if ( ( 'arrows' === navigation || 'arrows_dots' === navigation ) && ! masked ) { #>
				<div class="awb-swiper-button awb-swiper-button-prev"><i {{{ _.fusionGetAttributes( prevAttr ) }}}></i></div>
				<div class="awb-swiper-button awb-swiper-button-next"><i {{{ _.fusionGetAttributes( nextAttr ) }}}></i></div>
			<# } #>
		</div>
	<# } #>
</div>
</script>

<script type="text/html" id="tmpl-fusion_testimonial-shortcode">
<#
var thumbnail = '',
	image = '',
	initials = '',
	nameHtml = '',
	titleHtml = '',
	company = '',
	extras = '',
	companyName = '',
	combined_attribs = '',
	icon = '',
	triangle = '',
	rating = '',
	html = '';

// Avatar / thumbnail.
if ( 'none' !== values.avatar ) {
	if ( 'image' === values.avatar && values.image ) {
		image     = '<img ' + _.fusionGetAttributes( imageAttr ) + ' />';
		thumbnail = '<div ' + _.fusionGetAttributes( thumbnailAttr ) + '>' + image + '</div>';
	} else if ( 'initials' === values.avatar ) {
		var initialsName = ( values.name || '' ).replace( /<[^>]*>/g, '' ).replace( /^\s+|\s+$/g, '' );
		if ( initialsName ) {
			var nameParts = initialsName.split( /\s+/ );
			initials = nameParts[ 0 ].charAt( 0 );
			if ( 1 < nameParts.length ) {
				initials += nameParts[ nameParts.length - 1 ].charAt( 0 );
			}
			initials  = initials.toUpperCase();
			thumbnail = '<div ' + _.fusionGetAttributes( thumbnailAttr ) + '><span class="testimonial-initials-text">' + initials + '</span></div>';
		}
	} else if ( 'icon' === values.avatar ) {

		// Icon avatar: same chip as the initials one, with a glyph instead of the letters.
		if ( values.avatar_icon ) {
			thumbnail = '<div ' + _.fusionGetAttributes( thumbnailAttr ) + '><i ' + _.fusionGetAttributes( avatarIconAttr ) + '></i></div>';
		}
	} else if ( 'male' === values.avatar || 'female' === values.avatar ) {
		thumbnail = '<div ' + _.fusionGetAttributes( thumbnailAttr ) + '></div>';
	}
}

// Star rating.
var ratingValue = ( 'undefined' !== typeof values.rating && null !== values.rating ) ? values.rating.toString().replace( ',', '.' ) : '';
if ( '' !== ratingValue && ! isNaN( ratingValue ) ) {
	var ratingNum = parseFloat( ratingValue ),
		ratingMax = parseInt( parentValues.rating_max, 10 ) || 5;

	if ( ratingNum > ratingMax ) {
		ratingNum = ratingMax;
	}

	if ( 0 < ratingNum ) {
		var iconClass  = _.fusionFontAwesome( parentValues.rating_icon ),
			isWhole    = ( parseInt( ratingNum, 10 ) === ratingNum ),
			ratingIcons = '';

		for ( var s = 1; s <= ratingMax; s++ ) {
			if ( s <= ratingNum ) {
				ratingIcons += '<i class="' + iconClass + ' awb-stars-rating-filled-icon"></i>';
			} else if ( ! isWhole && ( parseInt( ratingNum, 10 ) + 1 ) === s ) {
				var partialWidth = parseInt( ( ratingNum - parseInt( ratingNum, 10 ) ) * 100, 10 ) + '%';
				ratingIcons += '<i class="' + iconClass + ' awb-stars-rating-partial-icon-wrapper"><i class="' + iconClass + ' awb-stars-rating-partial-icon" style="width:' + partialWidth + ';"></i></i>';
			} else {
				ratingIcons += '<i class="' + iconClass + ' awb-stars-rating-empty-icon"></i>';
			}
		}

		var ratingText = ( 'undefined' !== typeof values.rating_text && '' !== values.rating_text ) ? '<span class="awb-testimonial-rating-text">' + values.rating_text + '</span>' : '';

		rating = '<div class="awb-testimonial-rating"><div class="awb-stars-rating awb-stars-rating-no-text" role="img"><div class="awb-stars-rating-icons-wrapper">' + ratingIcons + '</div></div>' + ratingText + '</div>';
	}
}

// Author parts.
if ( values.name ) {
	nameHtml = '<strong class="testimonial-name">' + values.name + '</strong>';
}

if ( values.title_role ) {
	titleHtml = '<span class="testimonial-title">' + values.title_role + '</span>';
}

if ( values.testimonial_icon ) {
	icon = '<i ' + _.fusionGetAttributes( iconAttr ) + '></i>';
}

if ( values.company ) {
	if ( values.link && '' !== values.link ) {
		combined_attribs = 'target="' + values.target + '"';
		combined_attribs += ( '_blank' === values.target ) ? ' rel="noopener noreferrer"' : '';
		company = '<a href="' + values.link + '" ' + combined_attribs + '><span class="testimonial-company">' + values.company + '</span></a>';
	} else {
		company = '<span class="testimonial-company">' + values.company + '</span>';
	}
}

var extrasParts = [];
if ( titleHtml ) { extrasParts.push( titleHtml ); }
if ( company ) { extrasParts.push( company ); }
extras = extrasParts.join( '<span class="awb-testimonial-sep">, </span>' );

// Always wrapped so the role / company styling covers the separators too.
var extrasHtml = ( '' !== extras ) ? '<span class="testimonial-extras">' + extras + '</span>' : '';

if ( 'stacked' === parentValues.author_layout ) {
	companyName = nameHtml + extrasHtml;
} else {
	var inlineParts = [];
	if ( nameHtml ) { inlineParts.push( nameHtml ); }
	if ( '' !== extrasHtml ) { inlineParts.push( extrasHtml ); }
	companyName = inlineParts.join( '<span class="awb-testimonial-sep">, </span>' );
}

if ( 'clean' === parentValues.design ) {

	var author = '<div ' + _.fusionGetAttributes( authorAttr ) + '><span class="company-name">' + companyName + '</span></div>';

	if ( 'below' === values.avatar_position ) {
		html = rating + '<blockquote ' + _.fusionGetAttributes( blockquoteAttr ) + '><div ' + _.fusionGetAttributes( quoteAttr ) + '>' + icon + '<div ' + _.fusionGetAttributes( quoteContentAttr ) + '>' + FusionPageBuilderApp.renderContent( content, cid, parent ) + '</div></div></blockquote>' + thumbnail + author;
	} else {
		html = thumbnail + rating + '<blockquote ' + _.fusionGetAttributes( blockquoteAttr ) + '><div ' + _.fusionGetAttributes( quoteAttr ) + '>' + icon + '<div ' + _.fusionGetAttributes( quoteContentAttr ) + '>' + FusionPageBuilderApp.renderContent( content, cid, parent ) + '</div></div></blockquote>' + author;
	}

} else {
	// Card "With Author" rating renders inside the author block; otherwise it stays in the quote.
	var ratingInAuthor = ( 'card' === parentValues.design && ( 'above_author' === parentValues.rating_position || 'below_author' === parentValues.rating_position ) ),
		quoteRating    = ratingInAuthor ? '' : rating,
		authorExtra    = ratingInAuthor ? rating : '';

	var author = '<div ' + _.fusionGetAttributes( authorAttr ) + '>' + thumbnail + '<span class="company-name">' + companyName + '</span>' + authorExtra + '</div>';

	if ( 'show' === parentValues.testimonial_speech_bubble && 'card' !== parentValues.design ) {
		triangle = '<span class="awb-triangle"></span>';
	}

	// Classic: rating sits inside the speech bubble, above the quote text (order via CSS).
	html = '<blockquote><div ' + _.fusionGetAttributes( quoteAttr ) + '>' + quoteRating + icon  + '<div ' + _.fusionGetAttributes( quoteContentAttr ) + '>' + FusionPageBuilderApp.renderContent( content, cid, parent ) + '</div></div>' + triangle + '</blockquote>' + author;
}
#>
{{{ html }}}
</script>
