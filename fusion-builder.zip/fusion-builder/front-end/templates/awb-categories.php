<?php
/**
 * Underscore.js template
 *
 * @package fusion-builder
 * @since 3.16
 */

?>
<script type="text/html" id="tmpl-awb_categories-shortcode">
	<div {{{ _.fusionGetAttributes( attr ) }}}>
		{{{ output }}}
	</div>
</script>
