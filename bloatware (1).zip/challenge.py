import socketserver
import pathlib
import signal
import os
import pathlib
import pty
import tempfile

image_max_size = 4 * 1024

class Handler(socketserver.BaseRequestHandler):
    def handle(self):
        self.request.sendall(b":)\n")

        buffer = b''
        while b"\n" not in buffer:
            buffer += self.request.recv(1024)
        
        try:
            data = bytes.fromhex(buffer.decode().strip())
            assert len(data) < image_max_size
        except Exception as exp:
            self.request.sendall(b"nop\n" + str(exp).encode())
            return

        wd = tempfile.mkdtemp()
        
        with open(f"{wd}/wallpaper.jpg", "wb") as fd:
            fd.write(data)

        os.system(f"qemu-img create -f raw {wd}/assets.img 50M")
        os.system(f"mkfs.vfat {wd}/assets.img")
        os.system(f"mcopy -i {wd}/assets.img {wd}/wallpaper.jpg ::/wallpaper.jpg")

        cmd = [
            "/usr/bin/qemu-system-i386", 
            "-drive", f"format=raw,file=/flag",
            "-cdrom", f"/src/grub.iso",
            "-drive", f"file={wd}/assets.img,format=raw,id=assets_dis",
            "-display", "curses",
            "-monitor", "none",
            "-snapshot",
            # "-S", "-s", # debug
        ]

        self.request.sendall(b"Starting qemu...")

        devnull = os.open(os.devnull, os.O_RDONLY)
        os.dup2(devnull, 0)
        os.close(devnull)

        os.dup2(self.request.fileno(), 1)
        os.dup2(self.request.fileno(), 2)

        signal.signal(signal.SIGALRM, lambda n, sf: [
            self.request.sendall(b"try harder"),
            exit(-1)
            ])
        
        signal.alarm(60)
        os.environ["TERM"] = "xterm"
        pty.spawn(cmd)

with socketserver.ForkingTCPServer(("0.0.0.0", 1024), Handler) as server:
    server.allow_reuse_address = True
    server.serve_forever()

